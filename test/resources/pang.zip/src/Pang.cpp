#include "coordinadorpang.h"

int main(int argc,char* argv[])
{
	CoordinadorPang pang;
	pang.Run();

	return 0;   
}

